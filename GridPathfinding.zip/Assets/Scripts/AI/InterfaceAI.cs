using UnityEngine;

public interface InterfaceAI //interface for enemy ai 
{
    void MakeDecision(); //class that implements this interface will have this fucntion
}
